# Initialize all necessary objectives and settings at the start of the game
function hayneko:init/init_sidebar
function hayneko:init/init_belowname
function hayneko:init/init_menu_handler

function hayneko:init/init_items/init_mlg_platform

# init game timer
function hayneko:init/init_game_timer

# init items
function hayneko:init/init_items/init_mlg_platform

# init item timers (if any)
# function hayneko:init/init_item_timers/init_mlg_platform_timer

# scoreboard objectives remove playerXP



# scoreboard objectives remove pvp_timer

time set noon

# scoreboard objectives add playerXP xp


# scoreboard objectives add pvp_timer dummy {"text":"PVP 计时器","color":"red","bold":true,"italic":false}
# scoreboard players set @a pvp_timer 6



title @a reset

title @a times 0 10 5
