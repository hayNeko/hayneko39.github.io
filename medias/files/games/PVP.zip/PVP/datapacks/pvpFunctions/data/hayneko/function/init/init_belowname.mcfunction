scoreboard objectives remove playerHealth
scoreboard objectives add playerHealth health "❤"
scoreboard objectives setdisplay below_name playerHealth