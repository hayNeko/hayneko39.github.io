scoreboard objectives remove menuOpen
scoreboard objectives add menuOpen minecraft.used:minecraft.carrot_on_a_stick
scoreboard players set @a menuOpen 0