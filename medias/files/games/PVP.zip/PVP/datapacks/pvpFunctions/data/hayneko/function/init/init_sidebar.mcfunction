scoreboard objectives remove sidebarInfo

scoreboard objectives add sidebarInfo dummy {"text":"HAYNEKO 起床战争","color":"yellow","bold":true,"italic":false}
scoreboard objectives setdisplay sidebar sidebarInfo

# bed status