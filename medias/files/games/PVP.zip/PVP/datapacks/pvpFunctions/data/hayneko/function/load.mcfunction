say the datapack has been loaded


# if player does not have the menu item, give it. If it already exists, do nothing
give @a[tag=!has_menu] minecraft:carrot_on_a_stick[custom_name='{"text":"菜单（右键使用）","color":"yellow","italic":false}',unbreakable={show_in_tooltip:false}]
tag @a[tag=!has_menu] add has_menu

# give @r compass[custom_name='{"text":"开始游戏（右键开始游戏）","color":"aqua","italic":false}',unbreakable={show_in_tooltip:false}] 1