#  if player tries to leave the map, damage for 1 heart every second
#  map size: x=-120 to 120, z=-120 to 120

execute as @a at @s unless entity @s[x=-128,y=-256,z=-128,dx=257,dy=512,dz=257] run damage @s 3 outside_border
execute as @a[gamemode=survival] at @s unless entity @s[x=-120,y=-256,z=-120,dx=241,dy=512,dz=241] run title @s title {"text":"你正在离开地图范围！","color":"red","bold":true,"italic":false}

# if player fall into the void, kill and add 1 death count, add 1 point to killer if exists
execute as @a at @s if entity @s[y=-120,dy=-1600] run playsound minecraft:entity.enderman.death master @a 0 60 0 0.75 1 0.75
execute as @a at @s if entity @s[y=-120,dy=-1600] run title @s title {"text":"你掉入了虚空！","color":"red","bold":true,"italic":false}
execute as @a at @s if entity @s[y=-120,dy=-1600] run damage @s 100 minecraft:out_of_world