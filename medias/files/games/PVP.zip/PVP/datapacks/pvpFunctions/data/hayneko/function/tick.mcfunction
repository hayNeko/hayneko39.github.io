# pvp menu
# execute as @a at @s if score @s menuOpen 

# necessary effects
execute as @a at @s run effect give @s minecraft:night_vision 11 1 true
